﻿using var game = new slasher.Game1();
game.Run();

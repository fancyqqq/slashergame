﻿namespace slasher.HandleStateChain.Handler;

public class JumpStateHandler : IStateHandle
{
    public StateMachineInitialization StateMachine { get; }

    public JumpStateHandler(StateMachineInitialization stateMachine)
    {
        StateMachine = stateMachine;
    }

    public bool CanHandle()
    {
        return StateMachine.PlayerStateData.IsJumpPressed &&
               StateMachine.PlayerStateData.IsGrounded;
    }

    public void Handle()
    {
        //StateMachine.PlayerStateMachine.SwitchStates<JumpState>();
    }
}
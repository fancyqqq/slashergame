﻿namespace slasher.HandleStateChain.Handler;

public class IdleStateHandler : IStateHandle
{
    public StateMachineInitialization StateMachine { get; }

    public IdleStateHandler(StateMachineInitialization stateMachine)
    {
        StateMachine = stateMachine;
    }

    public bool CanHandle()
    {
        return !StateMachine.PlayerStateData.IsLeftPressed && !StateMachine.PlayerStateData.IsRightPressed &&
               !StateMachine.PlayerStateData.IsJumpPressed && StateMachine.PlayerStateData.IsGrounded;
    }

    public void Handle()
    {
        StateMachine.PlayerStateMachine.SwitchStates<IdleState>();
    }
}
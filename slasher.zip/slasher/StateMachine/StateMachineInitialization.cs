﻿namespace slasher;

public class StateMachineInitialization
{
    public StateMachine PlayerStateMachine { get; private set; }
    public TestPlayer TestPlayer { get; private set; }
    public PlayerStateData PlayerStateData { get; private set; }

    public StateMachineInitialization()
    {
        System.Diagnostics.Debug.WriteLine("check3");
        Initialize();
    }


    private void Initialize()
    {
        TestPlayer = new TestPlayer();
        PlayerStateData = new PlayerStateData();
        
        PlayerStateMachine = new StateMachine(
            new IdleState(PlayerStateData, TestPlayer, this),
            new RunState(PlayerStateData, TestPlayer, this)
        );

        PlayerStateMachine.SwitchStates<IdleState>();
    }
}
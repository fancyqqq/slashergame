﻿using Microsoft.Xna.Framework.Input;

namespace slasher;

public class InputReader
{
    private readonly PlayerStateData _stateData;

    public InputReader(PlayerStateData stateData)
    {
        _stateData = stateData;
    }

    public void Read(KeyboardState ks, MouseState ms)
    {
        _stateData.IsLeftPressed = ks.IsKeyDown(Keys.A);
        _stateData.IsRightPressed = ks.IsKeyDown(Keys.D);
        _stateData.IsJumpPressed = ks.IsKeyDown(Keys.Space);
    }
}
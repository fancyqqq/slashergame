﻿using Microsoft.Xna.Framework.Input;

namespace slasher;

public class RunState : PlayerBaseState
{
    public RunState(PlayerStateData data, TestPlayer testPlayer, StateMachineInitialization machineInitialization) :
        base(data, testPlayer, machineInitialization)
    {
    }

    public override void OnEnter()
    {
        System.Diagnostics.Debug.WriteLine("check2");
    }

    public override void OnExit()
    {
    }

    public override void OnUpdateBehaviour(KeyboardState ks)
    {
        System.Diagnostics.Debug.WriteLine("RUN");
    }
}
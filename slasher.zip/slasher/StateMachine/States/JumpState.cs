﻿namespace slasher;

public class JumpState
{
    
}
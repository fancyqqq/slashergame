﻿namespace slasher;

public class PlayerStateData
{
    public bool IsJumpPressed;
    public bool IsLeftPressed;
    public bool IsRightPressed;
    public bool IsAttackPressed;
    public bool IsDefendPressed;
    public bool IsSpecialPressed;
    public bool IsGrounded;
}